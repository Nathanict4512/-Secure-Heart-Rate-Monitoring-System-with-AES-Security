<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-05-04 22:29:30              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto SI6qa; EL80r: if (empty($_SESSION["\155\157\x64\x5f\151\x64"])) { goto XgTtK; } goto v8Q03; e2avd: session_destroy(); goto INL1t; v8Q03: EDLIE($zR2j7, "\x6c\157\147\x6f\x75\x74", "\x4c\x6f\147\147\145\x64\40\x6f\x75\x74"); goto WQLve; SI6qa: require_once "\56\56\57\x63\157\x6e\146\151\x67\56\160\x68\x70"; goto EL80r; WQLve: XgTtK: goto e2avd; INL1t: GKgm1("\154\x6f\x67\x69\156\x2e\160\x68\160");
