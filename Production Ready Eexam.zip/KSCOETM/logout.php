<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-05-04 22:29:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ivE2x; uA3Ya: session_destroy(); goto d2nLA; ivE2x: require_once "\143\x6f\156\x66\151\147\x2e\160\150\160"; goto uA3Ya; d2nLA: gkGM1("\x69\156\144\x65\170\x2e\x70\x68\160");
