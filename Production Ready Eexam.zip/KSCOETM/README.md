# E-Exam System — Setup Guide

## Requirements
- PHP 7.4+ with MySQLi extension
- MySQL / MariaDB 5.7+
- Apache or Nginx web server
- Works on LAN (server-side timer means all students use PHP time — no JS timing drift)

## Installation Steps

### 1. Upload Files
Upload all files to your web server (e.g. `/var/www/html/eexam/` or `htdocs/eexam/`)

### 2. Create Database
- Open phpMyAdmin (or MySQL CLI)
- Create database: `eexam_db`
- Import `database.sql`

### 3. Configure Database
Edit `config.php`:
```php
define('DB_HOST', 'localhost');   // your DB host
define('DB_USER', 'root');        // your DB username
define('DB_PASS', '');            // your DB password
define('DB_NAME', 'eexam_db');    // your DB name
```

### 4. Set Folder Permissions
```bash
chmod 775 uploads/logos
chmod 775 uploads/questions
```

### 5. Login
- **Admin:** `http://yourserver/eexam/admin/login.php`
  - Default password: **password** (change immediately in Settings)
- **Student:** `http://yourserver/eexam/`

---

## Admin Workflow

1. **Settings** → Set school name, upload logo, change password
2. **Classes** → Add classes (e.g. "200L Computer Science")
3. **Students** → Add students manually or upload CSV (`regno, full_name`)
4. **Exams** → Create exam (title, class, year, duration, questions to display, score per Q, rules)
5. **Questions** → Upload CSV questions for each exam, then edit to add images
6. **PINs** → Generate PINs, print and distribute to students
7. **Results** → Select exam to view results, export to CSV
8. **Sessions** → Monitor active sessions, reset locked sessions

---

## Student Workflow

1. Open student login page
2. Enter Registration Number + PIN
3. Click exam to start
4. Answer questions (keyboard: A/B/C/D for options, N/P for next/previous)
5. Submit when done (or auto-submit when time runs out)

---

## CSV Formats

### Students CSV (students.csv)
```
regno,full_name
CSC/2021/001,John Adebayo
CSC/2021/002,Fatima Usman
```

### Questions CSV (questions.csv)
```
question_text,option_a,option_b,option_c,option_d,correct_answer
What does CPU stand for?,Central Processing Unit,Computer Personal Unit,...,A
"What is 2² + 3²?",10,12,13,15,C
```
- `correct_answer` must be A, B, C, or D
- Wrap text containing commas in quotes
- Math symbols work fine in UTF-8 encoded CSV

---

## LAN Usage

The exam timer is **fully server-side** (`timer.php`):
- PHP calculates `end_time` at session start
- JS fetches timer every 5 seconds from server
- Local countdown is only visual — auto-submit triggers from server time
- All students on the same LAN use the same server clock ✅
- No timing drift between students ✅

---

## Security Notes

- Students can only use each PIN once
- Single-session enforcement (student locked after login)
- Admin must reset session if student disconnects
- Shuffled question order is saved per student (consistent on re-login)
- All answers auto-saved on selection
- Score calculated server-side on submit
