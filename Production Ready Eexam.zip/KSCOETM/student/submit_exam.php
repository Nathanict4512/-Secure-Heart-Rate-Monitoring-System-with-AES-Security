<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-05-04 22:29:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto cLgjC; ZZqJ0: header("\x4c\x6f\x63\141\164\x69\x6f\x6e\x3a\x20\x2e\56\x2f\x69\156\x64\x65\170\56\160\x68\160"); goto jjQ6h; XcZ62: if (N5dGt()) { goto G14xw; } goto ZZqJ0; b9pBR: require_once "\56\56\57\x63\157\x6e\x66\151\147\56\x70\150\160"; goto Y6G3R; jjQ6h: exit; goto lJz9D; hHY05: header("\x4c\157\x63\141\164\x69\x6f\x6e\x3a\x20\144\x61\163\150\x62\157\x61\162\x64\x2e\x70\150\160\77\163\x75\x62\155\x69\x74\164\x65\x64\x3d\x31"); goto UaQoR; CakLb: SAz_3($zR2j7, $VCxv5, $cKPb6); goto hHY05; cLgjC: session_start(); goto b9pBR; jOgM9: $VCxv5 = $_SESSION["\x73\x74\165\144\x65\x6e\x74\137\151\144"]; goto ahFwQ; Y6G3R: require_once "\x73\165\x62\155\x69\x74\x5f\150\145\x6c\160\x65\162\x2e\x70\x68\160"; goto XcZ62; lJz9D: G14xw: goto jOgM9; ahFwQ: $cKPb6 = (int) ($_POST["\145\170\141\155\x5f\x69\144"] ?? $_GET["\145\170\141\x6d\x5f\151\144"] ?? 0); goto CakLb; UaQoR: exit;
