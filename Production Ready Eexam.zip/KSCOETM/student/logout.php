<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-05-04 22:29:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto umBBq; wPqZ1: session_destroy(); goto MUdBl; MUdBl: header("\x4c\x6f\143\x61\164\x69\x6f\x6e\72\x20\x2e\56\x2f\151\x6e\144\x65\170\x2e\x70\x68\x70"); goto BgFIM; umBBq: session_start(); goto wPqZ1; BgFIM: exit;
