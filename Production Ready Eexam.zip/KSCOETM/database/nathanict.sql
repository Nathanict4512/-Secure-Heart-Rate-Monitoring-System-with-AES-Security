-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2026 at 01:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nathanict`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `created_at`) VALUES
(1, '100L', '2026-05-02 22:53:31');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL DEFAULT '',
  `course_title` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(200) NOT NULL,
  `year` varchar(10) NOT NULL,
  `duration_minutes` int(11) NOT NULL DEFAULT 30,
  `questions_to_display` int(11) NOT NULL DEFAULT 20,
  `score_per_question` decimal(5,2) NOT NULL DEFAULT 1.00,
  `rules` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `course_code`, `course_title`, `title`, `year`, `duration_minutes`, `questions_to_display`, `score_per_question`, `rules`, `is_active`, `created_at`) VALUES
(1, 'CSC101', 'Introduction to Computer Science', 'First Semester', '2025/2026', 3, 3, 1.00, '', 1, '2026-05-02 22:54:38');

-- --------------------------------------------------------

--
-- Table structure for table `exam_classes`
--

CREATE TABLE `exam_classes` (
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exam_classes`
--

INSERT INTO `exam_classes` (`exam_id`, `class_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_sessions`
--

CREATE TABLE `exam_sessions` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `pin_used` varchar(20) NOT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_time` timestamp NULL DEFAULT NULL,
  `time_left_seconds` int(11) DEFAULT NULL,
  `is_submitted` tinyint(1) DEFAULT 0,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `score` decimal(8,2) DEFAULT NULL,
  `login_count` int(11) DEFAULT 1,
  `is_locked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exam_sessions`
--

INSERT INTO `exam_sessions` (`id`, `regno`, `exam_id`, `pin_used`, `started_at`, `end_time`, `time_left_seconds`, `is_submitted`, `submitted_at`, `score`, `login_count`, `is_locked`) VALUES
(1, 'NATHAN/001', 1, 'BEMWMDCZ', '2026-05-03 23:17:39', '2026-05-04 08:20:39', 180, 0, NULL, 0.00, 2, 1),
(2, 'NATHAN/002', 1, 'QL6UF8R7', '2026-05-03 23:20:57', '2026-05-04 08:23:57', 180, 0, NULL, 2.00, 2, 1),
(3, 'NATHAN/003', 1, 'WKVZK4X7', '2026-05-03 23:29:17', '2026-05-04 08:32:17', 101, 1, '2026-05-03 23:30:41', 1.00, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `moderators`
--

CREATE TABLE `moderators` (
  `id` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(30) DEFAULT '',
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `moderators`
--

INSERT INTO `moderators` (`id`, `full_name`, `username`, `email`, `phone`, `password_hash`, `is_active`, `created_at`) VALUES
(1, 'Nathan Adelola', 'admin@siwes.edu.ng', 'nathani.k4@gmail.com', '08147754855', '$2y$10$PnzydSaak0099rHfjC.4euVGqJUP2N7r3MItcATE61OJbnyzIW8Hm', 1, '2026-05-02 22:57:18');

-- --------------------------------------------------------

--
-- Table structure for table `mod_activity_log`
--

CREATE TABLE `mod_activity_log` (
  `id` int(11) NOT NULL,
  `mod_id` int(11) NOT NULL,
  `mod_username` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mod_activity_log`
--

INSERT INTO `mod_activity_log` (`id`, `mod_id`, `mod_username`, `action`, `description`, `ip_address`, `created_at`) VALUES
(1, 1, 'admin@siwes.edu.ng', 'login', 'Logged in', '127.0.0.1', '2026-05-02 22:58:40'),
(2, 1, 'admin@siwes.edu.ng', 'add_student', 'Added student: Nathan Adelola (NATHAN/002)', '127.0.0.1', '2026-05-02 22:58:57'),
(3, 1, 'admin@siwes.edu.ng', 'page_unlock', 'Unlocked: results', '127.0.0.1', '2026-05-02 22:59:10'),
(4, 1, 'admin@siwes.edu.ng', 'logout', 'Logged out', '127.0.0.1', '2026-05-02 22:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `page_passwords`
--

CREATE TABLE `page_passwords` (
  `id` int(11) NOT NULL,
  `page_key` varchar(50) NOT NULL,
  `page_label` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL DEFAULT '',
  `is_enabled` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_passwords`
--

INSERT INTO `page_passwords` (`id`, `page_key`, `page_label`, `password_hash`, `is_enabled`) VALUES
(1, 'exams', 'Exams Page', '$2y$10$Y9qbDywVCiHu7ko7UmJByuzMBWzkEsXAXMkRpjF6fAT9/9choVDJW', 1),
(2, 'questions', 'Questions Page', '$2y$10$dYDMJ4fRpfTOrPtrydf2iOXpWjQHJAkuOnJlT8mCGHnj8JWPhif8O', 1),
(3, 'results', 'Results Page', '$2y$10$tpOyHpK3Ns.EoPljLfRij.tq3uGPJ6Umsb7B9RqKUEiXf9HcCGBfK', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pins`
--

CREATE TABLE `pins` (
  `id` int(11) NOT NULL,
  `pin_code` varchar(20) NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `used_by_regno` varchar(50) DEFAULT NULL,
  `used_by_name` varchar(200) DEFAULT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pins`
--

INSERT INTO `pins` (`id`, `pin_code`, `is_used`, `used_by_regno`, `used_by_name`, `used_at`, `created_at`) VALUES
(1, '434HQKLS', 1, 'NATHAN/001', 'Nathan Adelola', '2026-05-02 23:04:45', '2026-05-02 22:56:03'),
(2, 'BEMWMDCZ', 1, 'NATHAN/001', 'Nathan Adelola', '2026-05-02 23:03:13', '2026-05-02 22:59:03'),
(3, '2MK2BU9V', 1, 'NATHAN/001', 'Nathan Adelola', '2026-05-02 23:07:38', '2026-05-02 23:07:26'),
(4, 'QL6UF8R7', 1, 'NATHAN/002', 'Nathan Adelola', '2026-05-03 01:06:48', '2026-05-03 01:06:34'),
(5, 'MBXVJCV3', 1, 'NATHAN/001', 'Nathan Adelola', '2026-05-03 23:17:53', '2026-05-03 23:17:16'),
(6, 'GF5VB22S', 1, 'NATHAN/002', 'Nathan Adelola', '2026-05-03 23:20:16', '2026-05-03 23:19:55'),
(7, 'QUYBV7HC', 1, 'NATHAN/002', 'Nathan Adelola', '2026-05-03 23:21:32', '2026-05-03 23:19:55'),
(8, 'WKVZK4X7', 1, 'NATHAN/003', 'Nathan Adelola', '2026-05-03 23:23:02', '2026-05-03 23:19:55'),
(9, 'QQ8M9DWZ', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(10, '7RVPGU9T', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(11, '7JURLUEQ', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(12, 'L8FSWM86', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(13, 'GVYHBDVS', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(14, 'FN2TYMCK', 0, NULL, NULL, NULL, '2026-05-03 23:19:55'),
(15, 'X7RAJPAE', 0, NULL, NULL, NULL, '2026-05-03 23:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `correct_answer` char(1) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `exam_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `image_path`, `created_at`) VALUES
(19, 1, 'What is ?16?', '2', '4', '8', '16', 'B', NULL, '2026-05-03 02:34:37'),
(20, 1, 'Solve 2x+4=10', 'x=2', 'x=3', 'x=4', 'x=5', 'B', NULL, '2026-05-03 02:34:37'),
(21, 1, 'A ? B is called?', 'Union', 'Intersection', 'Subset', 'Universal', 'B', NULL, '2026-05-03 02:34:37'),
(22, 1, 'What is ? approximately?', '2.14', '3.14', '4.13', '3.41', 'B', NULL, '2026-05-03 02:34:37'),
(23, 1, 'If A ∩ B = ∅, then sets are?', 'If A ∩ B = ∅, then sets are?', 'Disjoint', 'Subset', 'Universal', 'B', 'q_23_1777775737.png', '2026-05-03 02:34:37'),
(24, 1, 'Solve: 3² + 4²', '25', '18', '49', '12', 'A', NULL, '2026-05-03 02:34:37');

-- --------------------------------------------------------

--
-- Table structure for table `session_question_order`
--

CREATE TABLE `session_question_order` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `session_question_order`
--

INSERT INTO `session_question_order` (`id`, `regno`, `exam_id`, `question_id`, `position`) VALUES
(1, 'NATHAN/001', 1, 2, 1),
(2, 'NATHAN/001', 1, 1, 2),
(3, 'NATHAN/001', 1, 4, 3),
(4, 'NATHAN/002', 1, 18, 1),
(5, 'NATHAN/002', 1, 17, 2),
(6, 'NATHAN/003', 1, 23, 1),
(7, 'NATHAN/003', 1, 19, 2),
(8, 'NATHAN/003', 1, 22, 3);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`) VALUES
(1, 'school_name', 'KSCOETM'),
(2, 'school_logo', 'logo_1777761439.png'),
(6, 'admin_password', '$2y$10$wbwbBScz7Q/Qw9uQHNsg9.eAJ2.PHqUlTQ6TCLTcNY2fQ2k8KMmei');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `regno`, `full_name`, `class_id`, `created_at`) VALUES
(4, 'NATHAN/003', 'Nathan Adelola', 1, '2026-05-03 23:22:32');

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `selected_answer` char(1) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT 0,
  `answered_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`id`, `regno`, `exam_id`, `question_id`, `selected_answer`, `is_correct`, `answered_at`) VALUES
(1, 'NATHAN/001', 1, 2, 'B', 0, '2026-05-02 23:08:37'),
(2, 'NATHAN/001', 1, 1, 'A', 0, '2026-05-02 23:08:41'),
(3, 'NATHAN/001', 1, 4, 'D', 0, '2026-05-02 23:08:43'),
(4, 'NATHAN/002', 1, 18, 'A', 1, '2026-05-03 01:06:52'),
(5, 'NATHAN/002', 1, 17, 'B', 1, '2026-05-03 01:07:17'),
(6, 'NATHAN/003', 1, 23, 'A', 0, '2026-05-03 23:23:18'),
(7, 'NATHAN/003', 1, 19, 'B', 1, '2026-05-03 23:30:30'),
(8, 'NATHAN/003', 1, 22, 'A', 0, '2026-05-03 23:30:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_classes`
--
ALTER TABLE `exam_classes`
  ADD PRIMARY KEY (`exam_id`,`class_id`);

--
-- Indexes for table `exam_sessions`
--
ALTER TABLE `exam_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_exam` (`regno`,`exam_id`);

--
-- Indexes for table `moderators`
--
ALTER TABLE `moderators`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `mod_activity_log`
--
ALTER TABLE `mod_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_passwords`
--
ALTER TABLE `page_passwords`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_key` (`page_key`);

--
-- Indexes for table `pins`
--
ALTER TABLE `pins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pin_code` (`pin_code`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_exam` (`exam_id`);

--
-- Indexes for table `session_question_order`
--
ALTER TABLE `session_question_order`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_order` (`regno`,`exam_id`,`position`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `regno` (`regno`),
  ADD KEY `idx_class` (`class_id`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_answer` (`regno`,`exam_id`,`question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_sessions`
--
ALTER TABLE `exam_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `moderators`
--
ALTER TABLE `moderators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mod_activity_log`
--
ALTER TABLE `mod_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `page_passwords`
--
ALTER TABLE `page_passwords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pins`
--
ALTER TABLE `pins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `session_question_order`
--
ALTER TABLE `session_question_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
