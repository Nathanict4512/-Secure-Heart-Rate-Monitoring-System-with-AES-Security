<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-05-04 22:29:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto EXCdq; EXCdq: define("\132\147\x4a\113\101", "\154\157\x63\141\x6c\150\x6f\163\x74"); goto qUnrI; DJmhH: x8PXJ: goto sRe52; Mz6kQ: define("\x6e\x66\x67\145\123", "\156\x61\x74\x68\x61\x6e\x69\x63\x74"); goto x5D2E; mQCNr: exit; goto DJmhH; fKG_P: define("\x4c\144\x30\121\127", ''); goto Mz6kQ; B4yOJ: $zR2j7 = new mysqli(ZgJKA, HuEt0, Ld0QW, nfgeS); goto rRIpT; sRe52: vzSks: goto jJKzN; tuvFM: header("\114\157\x63\141\x74\x69\157\156\x3a\40\151\x6e\x73\164\141\154\154\x2e\x70\150\160"); goto mQCNr; rRIpT: if (!$zR2j7->connect_error) { goto vzSks; } goto rPmv3; jJKzN: if (!($zR2j7 && !$zR2j7->connect_error)) { goto uwKji; } goto IYEEp; qUnrI: define("\x48\165\105\x74\60", "\162\157\157\x74"); goto fKG_P; IYEEp: $zR2j7->set_charset("\x75\x74\146\70\x6d\142\64"); goto ALDvz; x5D2E: define("\x74\x35\150\x66\147", dirname(__FILE__)); goto B4yOJ; ALDvz: uwKji: goto N7rJ4; rPmv3: if (defined("\152\x69\153\141\x6f")) { goto x8PXJ; } goto tuvFM; N7rJ4: require_once __DIR__ . "\x2f\x63\x6f\x6e\x66\x69\147\x5f\146\x75\x6e\143\x74\151\157\156\163\56\160\x68\160";
